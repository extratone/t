# README
# Social
[https://twitter.com/NeoYokel/status/1352565461259575298](https://twitter.com/NeoYokel/status/1352565461259575298)

[https://www.facebook.com/pissdavidblue/](https://www.facebook.com/pissdavidblue/)

[https://bit.ly/bluepiss](https://bit.ly/bluepiss)

[For God's Sake, Just Sit Down to Piss, organized by David Blue](http://gofundme.com/f/sit-down-to-piss)

- - - -

[For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Have_You_Ever_Gotten_Laid_Because_of_A_Car.mp3](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Have_You_Ever_Gotten_Laid_Because_of_A_Car.mp3)

# *You better change your fucking angle, homie...
Yeah, you better develop your life, son...*

You can literally follow my live progress on [the main manuscript](https://eileenlong-my.sharepoint.com/:w:/g/personal/david_eileenlonglcsw_com/EX8LNxS3dtpHisjBIUvv-WcBRR0WigNk94H0VUPDY5-WXg?e=bcEmRD), if you'd like.

[Piss Chapter Outline](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Piss%20Chapter%20Outline%206760e510615448f19ac02a00daec0796.csv)

# General Notes
[Opinion | If Classics Doesn't Change, Let It Burn](https://www.chronicle.com/article/if-classics-doesnt-change-let-it-burn)

Elon Musk is a shithead.

Catcalling

Clothes

Stuff we should keep to ourselves

Credits “I’m laughing at you and the best part is you won’t truly understand why, in any deep and meaningful way, for another 20 years.” - JustSomeGuy on Mastodon

#piss