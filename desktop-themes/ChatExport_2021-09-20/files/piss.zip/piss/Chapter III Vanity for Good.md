# Chapter III: Vanity for Good
Created: Nov 1, 2020 6:20 PM

## Instead of Elon Musk, Jon Male is your hero...

- - - -
# Tesla
![](Chapter%20III%20Vanity%20for%20Good/Untitled.png)Vanity%20for%20Good%20a57a3dc04de84f258c844faf3d4c33af/Untitled.png

[How Elon Musk Turned Tesla Into the Car Company of the Future | WIRED](Vanity%20for%20Good%20a57a3dc04de84f258c844faf3d4c33af/Chapter%203%20References%20b4c5a616d7524b2a807cb5e320c87082/How%20Elon%20Musk%20Turned%20Tesla%20Into%20the%20Car%20Company%20of%20e57d045c58924ad6b397e95199f3296a.md)

The fact that Tesla was handed **half a fucking billion dollars in public** money after only **a single year** and having only produced ~1300 little electric Lotus sports cars is absolutely unbelievable. [How Elon Musk Turned Tesla Into the Car Company of the Future | WIRED](Vanity%20for%20Good%20a57a3dc04de84f258c844faf3d4c33af/Chapter%203%20References%20b4c5a616d7524b2a807cb5e320c87082/How%20Elon%20Musk%20Turned%20Tesla%20Into%20the%20Car%20Company%20of%20e57d045c58924ad6b397e95199f3296a.md)

# Musk

- [ ]  The story of the taxi driver in Portland

- - - -

[Chapter 3 References](Vanity%20for%20Good%20a57a3dc04de84f258c844faf3d4c33af/Chapter%203%20References%20b4c5a616d7524b2a807cb5e320c87082.csv)

#piss