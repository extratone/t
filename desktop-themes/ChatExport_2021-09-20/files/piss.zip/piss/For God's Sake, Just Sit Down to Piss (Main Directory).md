# For God's Sake, Just Sit Down to Piss (Main Directory)
[For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Piss_Hand_Notes_(Diamond_Journal_Part_2).pdf](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Piss_Hand_Notes_(Diamond_Journal_Part_2).pdf)

# Social
[https://twitter.com/NeoYokel/status/1352565461259575298](https://twitter.com/NeoYokel/status/1352565461259575298)

[https://www.facebook.com/pissdavidblue/](https://www.facebook.com/pissdavidblue/)

[https://bit.ly/bluepiss](https://bit.ly/bluepiss)

[For God's Sake, Just Sit Down to Piss, organized by David Blue](http://gofundme.com/f/sit-down-to-piss)

- - - -

[For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Have_You_Ever_Gotten_Laid_Because_of_A_Car.mp3](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Have_You_Ever_Gotten_Laid_Because_of_A_Car.mp3)

# *You better change your fucking angle, homie...
Yeah, you better develop your life, son...*

You can literally follow my live progress on [the main manuscript](https://eileenlong-my.sharepoint.com/:w:/g/personal/david_eileenlonglcsw_com/EX8LNxS3dtpHisjBIUvv-WcBRR0WigNk94H0VUPDY5-WXg?e=bcEmRD), if you'd like.

[Piss Chapter Outline](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Piss%20Chapter%20Outline%206760e510615448f19ac02a00daec0796.csv)

# General Notes
[Opinion | If Classics Doesn't Change, Let It Burn](https://www.chronicle.com/article/if-classics-doesnt-change-let-it-burn)

Elon Musk is a shithead.

Catcalling

Clothes

Stuff we should keep to ourselves

Credits “I’m laughing at you and the best part is you won’t truly understand why, in any deep and meaningful way, for another 20 years.” - JustSomeGuy on Mastodon

- - - -

[A Data-Led Theory to Generationally Divide Dance Floors](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/A%20Data-Led%20Theory%20to%20Generationally%20Divide%20Dance%20F%20ead34b99ee0749228b7403d6b20db296.md)

[Longform Podcast #308: Jon Caramanica · Longform](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Longform%20Podcast%20#308%20Jon%20Caramanica%20%C2%B7%20Longform%20150eaffc9e45488789a287f0add536ef.md)

[https://www.youtube.com/watch?v=jNmmVEXk0EY&feature=share](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/https%20www%20youtube%20com%20watch%20v=jNmmVEXk0EY&feature=%207f36bad51d0b4148b0c9d21d6df254b0.md)

[Nonfiction Book Proposal Outline | Ted Weinstein Literary Management](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Nonfiction%20Book%20Proposal%20Outline%20Ted%20Weinstein%20Lit%203d66cb32bdbe4a77996013aace04d5a9.md)

[How to Write Your Nonfiction Book | Nonfiction Authors Association](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/How%20to%20Write%20Your%20Nonfiction%20Book%20Nonfiction%20Autho%20849dcd236e3649b3a024a08bf4438bf2.md)

[How To Write A Nonfiction Book | TCK Publishing](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/How%20To%20Write%20A%20Nonfiction%20Book%20TCK%20Publishing%20d904eb3c08924d3f8182b7e91a4b61ee.md)

[Library](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Library%202dd57658d61a4202910a21d7f4d329b9.csv)

[Library](For%20God's%20Sake,%20Just%20Sit%20Down%20to%20Piss%2014836c7770e2442fa2acd4ae1e297dbd/Library%2054c054996c644030b42a30ca1adfbab7.csv)

#piss