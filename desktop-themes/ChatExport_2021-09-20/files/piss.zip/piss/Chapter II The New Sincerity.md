# Chapter II: The New Sincerity
Created: Nov 4, 2020 3:38 AM

- - - -

[https://youtu.be/jNmmVEXk0EY](https://youtu.be/jNmmVEXk0EY)

[The New Sincerity References](The%20New%20Sincerity%2015be62fa10194e4db0cf70e8ea84fba2/The%20New%20Sincerity%20References%2031a2dd7faf2e421b848f7e4a84762d2e.csv)
#piss