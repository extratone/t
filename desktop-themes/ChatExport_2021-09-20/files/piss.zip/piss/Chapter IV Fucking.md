# Chapter IV: Fucking
* I am going to have to be sexually explicit in this book…
* Beginning with the assumptions that are required to continue reading the book, period. (Namely around consent.)
* You must like the way vagina tastes. (You must *actually like vagina* if you’re going to be a straight cis sexually-active male.) 
* You absolutely must reach a point where menstruation is not uncomfortable to think about, generally.
* You must reach a point where you would be okay with performing oral sex on a woman who is menstruating. Distinctly *not* *thrilled about*, necessarily… Just okay with.

#piss