# Preface: DISCLAIMATION
Created: Oct 7, 2020 7:55 PM

If something pisses you off, call or text me! My personal cellular number is printed on the inside of the cover and on the last page.

- - - -
- [ ]  Not necessarily directed at young men of color. (Or definitely not directed at them, but at white, CIS, straight young men.)
- [ ]  Describing the “real” scope of my authority.
	* While I have not traveled outside of America whatsoever, I have traveled within it fairly extensively.
	* My authority is especially strong when it comes to protestant Christianity.
- [ ]  Function of the book.


#piss